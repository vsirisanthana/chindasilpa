<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Thaiis Administrator Panel</title>
<link href="adminpanel.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="main_panel">
  <div id="header"></div>
  <div id="contenter">
    <div id="headpanel"><img src="images/admin_07.jpg" alt="Thaiis Administratorpanel" /></div>
	<div id="content_panel">
	  <ul class="linkul">
	  <li class="linkli"><a href="cms">Thaiis content management system</a></li>
	  <li class="linkli"><a href="photo/admin">Thaiis photo gallery system</a></li>
	  </ul>
    </div>
  </div>
  <div id="footer">
    <ul class="footmenu">
	<li class="linefoot"><a href="http://www.thaiis.net"><img src="images/footmenu_16.jpg" alt="THAIIS.NET" border="0" /></a></li>
	<li class="linefoot"><a href="http://www.thaiis.com"><img src="images/footmenu_17.jpg" alt="THAIIS.COM" border="0" /></a></li>
	<li class="linefoot"><a href="http://www.thaiis.org"><img src="images/footmenu_18.jpg" alt="THAIIS.COM" border="0" /></a></li>
	<li class="linefoot"><a href="http://www.thaiis.us"><img src="images/footmenu_19.jpg" alt="THAIIS.COM" border="0" /></a></li>
	<li class="linefoot"><a href="http://www.thaiis.co.th"><img src="images/footmenu_20.jpg" alt="THAIIS.COM" border="0" /></a></li>
	<li class="linefoot"><a href="http://www.thaiis.biz"><img src="images/footmenu_21.jpg" alt="THAIIS.COM" border="0" /></a></li>
	<li class="linefoot"><a href="http://www.thaiis.info"><img src="images/footmenu_22.jpg" alt="THAIIS.COM" border="0" /></a></li>
    </ul>
    <div id="copyright">Copyright 2006 Thai Tnteractive Studio Company Limited. all right reserved.</div>
  </div>
</div>
</body>
</html>
