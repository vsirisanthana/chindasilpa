<?PHP die("You don't have access to open this file !!!"); ?>
1172484862|1|admin|81ef9c35ace337d0a7dcd285ad514b44|admin|design@thaiis.net|11|0||1216111418||
1172656600|2|thekad|35e30d44820895a43fe77bc2397c0ad4|thekad|contact@thekad.info|0|0||1172796658||
