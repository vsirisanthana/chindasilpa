<?PHP 

//System Configurations (Auto Generated file)

$config_http_script_dir = "http://www.thekad.info/cms";

$config_skin = "default";

$config_date_adjust = "0";

$config_smilies = "smile,wink,wassat,tongue,laughing,sad,angry,crying";

$config_auto_archive = "no";

$config_allow_registration = "no";

$config_registration_level = "4";

$config_use_avatar = "no";

$config_use_wysiwyg = "yes";

$config_reverse_active = "no";

$config_timestamp_active = "d M Y";

$config_full_popup = "no";

$config_full_popup_string = "HEIGHT=400,WIDTH=650,resizable=yes,scrollbars=yes";

$config_show_comments_with_full = "no";

$config_auto_wrap = "44";

$config_reverse_comments = "no";

$config_flood_time = "15";

$config_comment_max_long = "1500";

$config_comments_per_page = "50";

$config_only_registered_comment = "no";

$config_allow_url_instead_mail = "no";

$config_timestamp_comment = "d M Y h:i a";

$config_comments_popup = "no";

$config_comments_popup_string = "HEIGHT=400,WIDTH=650,resizable=yes,scrollbars=yes";

$config_show_full_with_comments = "no";

$config_notify_email = "design@thaiis.net";

$config_notify_status = "disabled";

$config_notify_registration = "no";

$config_notify_comment = "no";

$config_notify_unapproved = "no";

$config_notify_archive = "no";

$config_notify_postponed = "no";

?>