<?php
// this is the file used to connect to your database.
// you must change these values in order to run the gallery.
define("PLOGGER_DB_HOST","localhost");
define("PLOGGER_DB_USER","chinda_img");
define("PLOGGER_DB_PW","cwep7");
define("PLOGGER_DB_NAME","chinda_img");
?>
