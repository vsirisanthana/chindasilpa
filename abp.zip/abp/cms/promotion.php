<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>

<body>
<table width="434" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="10" valign="top">&nbsp;</td>
    <td width="413" valign="top"><?	
//	if($_GET[subaction]){
$category="2";
		include("../cms/show_news.php");
//	}
?></td>
    <td width="10" valign="top">&nbsp;</td>
  </tr>
</table>
</body>
</html>
