<html><!-- #BeginTemplate "/Templates/themes.dwt" --><!-- DW6 -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title>ABP Airport Business Centre</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<link rel="stylesheet" href="css/abp.css" type="text/css">
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="MM_preloadImages('images/langover_01.jpg','images/langover_02.jpg')">
<table width="772" cellpadding="0" cellspacing="0" border="0" class="bghead" height="209">
  <tr> 
    <td valign="top"> <br>
      <table width="772" border="0">
        <tr> 
          <td width="55">&nbsp;</td>
          <td rowspan="2" valign="top"> 
            <p><br>
              <img src="images/logo_abp.gif" width="143" height="75"></p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p align="center"><a href="../th/index.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image10','','images/langover_01.jpg',1)"><br>
              <img name="Image10" border="0" src="images/lang_01.jpg" width="56" height="33"></a><a href="index.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image11','','images/langover_02.jpg',1)"><img name="Image11" border="0" src="images/lang_02.jpg" width="55" height="33"></a><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="139" height="345">
                <param name=movie value="menu.swf">
                <param name=quality value=high>
                <param name="wmode" value="transparent">
                <embed src="menu.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="139" height="345" wmode="transparent">
                </embed> 
              </object>
            <table width=135 border=0 cellpadding=0 cellspacing=0 align="center">
              <tr> 
                <td> <img src="images/solucut_01.jpg" width=135 height=42 alt=""></td>
              </tr>
              <tr> 
                <td> <a href="smartoffice.htm"><img src="images/solucut_02.jpg" width=135 height=93 alt="" border="0"></a></td>
              </tr>
              <tr> 
                <td> <a href="virtualoffice.htm"><img src="images/solucut_03.jpg" width=135 height=94 alt="" border="0"></a></td>
              </tr>
              <tr> 
                <td> <a href="businesscenter.htm"><img src="images/solucut_04.jpg" width=135 height=126 alt="" border="0"></a></td>
              </tr>
            </table>
            <div align="center"><a href="telleng.php"><img src="images/tell.gif" width="126" height="24" border="0"></a> 
            </div>
            <p>&nbsp;</p>
          </td>
          <td width="529" valign="top"><!-- #BeginEditable "hd" --><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="570" height="251">
              <param name=movie value="head-home.swf">
              <param name=quality value=high>
              <param name="wmode" value="transparent">
              <embed src="head-home.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="570" height="251" wmode="transparent">
              </embed> 
            </object><!-- #EndEditable --> </td>
        </tr>
        <tr> 
          <td width="55">&nbsp;</td>
          <td width="529" valign="top">
            <table width="100%">
              <tr> 
                <td width="40" valign="top">&nbsp;</td>
                <td valign="top" width="548"><!-- #BeginEditable "boo" --> 
                  <p><b>Tell a friend about our site!</b><br>
                    <?php
If ($to_email && $message && $subject) {$to = "\"$to_name\" <$to_email>";
$from = "\"$from_name\" <$from_email>";
$to = str_replace("\\'", "'", $to);
$from = str_replace("\\'", "'", $from);$subject = str_replace("\\'", "'", $subject);
$message = str_replace("\\'", "'", $message);
mail($to, $subject, $message, "From: $from\nX-Mailer: TYPE YOUR BUSINESS NAME HERE");
echo "Mail message sent : \nTo : $to\nFrom : $from\nSubject : $subject\nMessage : $message";
exit; } ?>
                  <? if (empty($HTTP_REFERER)) { $referrer = 'No referrer reported'; } else { $referrer = $HTTP_REFERER; } echo $referrer; ?></p>
                  <form action=<?php echo $PHP_SELF; ?> METHOD=POST>
                    <table width="500" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td>To (Friend's name):</td>
                        <td><input type=text name=to_name></td>
                      </tr>
                      <tr> 
                        <td>To (Friend's email): </td>
                        <td><input type=text name=to_email></td>
                      </tr>
                      <tr> 
                        <td>From (Your name): </td>
                        <td><input type=text name=from_name></td>
                      </tr>
                      <tr> 
                        <td>From (Your email): </td>
                        <td><input type=text name=from_email></td>
                      </tr>
                      <tr> 
                        <td>Subject : </td>
                        <td><input type=text name=subject></td>
                      </tr>
                      <tr> 
                        <td valign="top">Message</td>
                        <td><textarea name=message cols=30 rows=10>Link:
<? if (empty($HTTP_REFERER)) { $referrer = 'No referrer reported'; } else { $referrer = $HTTP_REFERER; } echo $referrer; ?>
</textarea></td>
                      </tr>
                      <tr>
                        <td valign="top">&nbsp;</td>
                        <td><br>
                          <input name="submit" type=submit value=Mail></td>
                      </tr>
                    </table>
                    </form></p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p><br>
                  </p>
                  <!-- #EndEditable --></td>
              </tr>
            </table>
            <table width="516" border="0" height="34">
              <tr> 
                <td width="46">&nbsp;</td>
                <td>
<hr>
                  <b><span class="small"><img src="images/link.jpg" width="24" height="24"></span><font color="#CC6666">Site 
                  map</font> <br>
                  <a href="index.htm"><span class="small">Home</span></a><span class="small"> 
                  |<a href="about.htm">About ABP</a>|<a href="solution.htm">ABP 
                  Solution</a> </span></b><span class="small">| <a href="smartoffice.htm">Smart 
                  Office</a>| <a href="virtualoffice.htm">Virtual Office</a>| 
                  <a href="businesscenter.htm">Business Center</a><b>|<a href="option.htm">Support 
                  Service</a>|<a href="serviceoption.htm">Service Option</a>|<a href="location.htm">Location</a></b>| 
                  <a href="map.htm">Map</a><b>|<a href="floorplan.htm">Floor 
                  Plan</a></b>| <a href="virtual.htm">Slide Show</a>| <a href="virtual1.htm">Landscape</a>| 
                  <a href="virtual2.htm">Entrance</a>| <a href="virtual3.htm">Reception</a>| 
                  <a href="virtual4.htm">Meeting Room</a>| <a href="virtual5.htm">Coffee 
                  Corner</a>| <a href="virtual6.htm">Smart Office</a><b> |<a href="contact.htm">Contact 
                  Us</a></b>|</span></td>
              </tr>
            </table>
            <p align="left">&nbsp;</p>
          </td>
        </tr>
      </table>
      <table width="772" bgcolor="#009999">
        <tr> 
          <td width="192">&nbsp;</td>
          <td width="417"><img src="images/c.gif"></td>
          <td width="147">&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
