<?
	require("../phpmailer/class.phpmailer.php");
?>
<html><!-- #BeginTemplate "/Templates/themes.dwt" --><!-- DW6 -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title>Air Port Business Park</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<link rel="stylesheet" href="css/abp.css" type="text/css">
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="MM_preloadImages('images/langover_01.jpg','images/langover_02.jpg')">
<table width="772" cellpadding="0" cellspacing="0" border="0" class="bghead" height="209">
  <tr> 
    <td valign="top"> <br>
      <table width="772" border="0">
        <tr> 
          <td width="55">&nbsp;</td>
          <td rowspan="2" valign="top"> 
            <p><br>
              <img src="images/logo_abp.gif" width="143" height="75"></p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p align="center"><a href="file:///C|/Documents%20and%20Settings/USER/Desktop/abp%20animate/th/index.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image10','','images/langover_01.jpg',1)"><br>
              <img name="Image10" border="0" src="images/lang_01.jpg" width="56" height="33"></a><a href="index.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image11','','images/langover_02.jpg',1)"><img name="Image11" border="0" src="images/lang_02.jpg" width="55" height="33"></a><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="139" height="345">
                <param name=movie value="menu.swf">
                <param name=quality value=high>
                <param name="wmode" value="transparent">
                <embed src="menu.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="139" height="345" wmode="transparent">
                </embed> 
              </object>
            <table width=135 border=0 cellpadding=0 cellspacing=0 align="center">
              <tr> 
                <td> <img src="images/solucut_01.jpg" width=135 height=42 alt=""></td>
              </tr>
              <tr> 
                <td> <a href="smartoffice.htm"><img src="images/solucut_02.jpg" width=135 height=93 alt="" border="0"></a></td>
              </tr>
              <tr> 
                <td> <a href="virtualoffice.htm"><img src="images/solucut_03.jpg" width=135 height=94 alt="" border="0"></a></td>
              </tr>
              <tr> 
                <td> <a href="businesscenter.htm"><img src="images/solucut_04.jpg" width=135 height=126 alt="" border="0"></a></td>
              </tr>
            </table>
            <div align="center"><a href="telleng.php"><img src="images/tell.gif" width="126" height="24" border="0"></a> 
            </div>
            <p>&nbsp;</p>
          </td>
          <td width="529" valign="top"><!-- #BeginEditable "hd" --><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="570" height="251">
              <param name=movie value="head-contact.swf">
              <param name=quality value=high>
              <param name="wmode" value="transparent">
              <embed src="head-contact.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="570" height="251" wmode="transparent">
              </embed> 
            </object><!-- #EndEditable --> </td>
        </tr>
        <tr> 
          <td width="55">&nbsp;</td>
          <td width="529" valign="top">
            <table width="100%">
              <tr> 
                <td width="40" valign="top">&nbsp;</td>
                <td valign="top" width="548"><!-- #BeginEditable "boo" --> 
                  <h1><img src="images/header_22.jpg" width="346" height="40"></h1>
                  <form method=POST action="sent.php">
                    <table width=427 border=0 align=center cellpadding=2 cellspacing=2 bgcolor="#FFFFFF">
                      <tbody> 
                      <tr bgcolor="#66CCCC"> 
                        <td width="413" bgcolor="#FFFFFF"> 
                          <div align="right"> 
                            <p align="center"><strong><font color="#666666"> <br>
                              </font><font color="#F4FCD8"><b><font color="#CC9933"><font size="2"> 
                              <?function check_email($_)
{ 
$_= !eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$", $_);

return $_; 
}

if ($name=='') { echo "<b><font color=\"#CC9933\"><font size=\"3\" face=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#CC0000\">Error</font><font size=\"2\"></font></font></b> <br>Please fill in<font color=\"#CC0000\">\"Name\"</font>
<br><a href=\"javascript:history.go(-1);\"><img src=\"images/back.gif\" width=\"37\" height=\"14\" border=\"0\"></a>"; }

else if ($email=='') { echo "<b><font color=\"#CC9933\"><font size=\"3\" face=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#CC0000\">Error</font><font size=\"2\"></font></font></b> <br>Please fill in <font color=\"#CC0000\">\"E-mail Address\"</font>
<br><a href=\"javascript:history.go(-1);\"><img src=\"images/back.gif\" width=\"37\" height=\"14\" border=\"0\"></a>"; }

else if ($email=='') { echo "<b><font color=\"#CC9933\"><font size=\"3\" face=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#CC0000\">Error</font><font size=\"2\"></font></font></b> <br>Please fill in <font color=\"#CC0000\">\"E-mail Address\"</font>
<br><a href=\"javascript:history.go(-1);\"><img src=\"images/back.gif\" width=\"37\" height=\"14\" border=\"0\"></a>"; }


else {
			 $msg="
<strong>Contact Us</strong><br />

Name= $name<br />
Company= $company<br />
Email Address= $email<br />
Telephone= $telephone<br />
Fax= $fax<br />
Mobile= $mobile<br />
Address= $address<br />
City= $city<br />
State= $state<br />
Country= $country<br />
PastalCode= $postalcode<br />

Service Type= $service $virtual $metting<br />

<strong>Size of Office</strong><br />
Width= $width<br />
Length= $length<br />
No. of Staff= $staff<br />
Expected Move-in Time= $date / $month / $year<br />
Additional Requirements>= $requirements<br />




			";
			$mail = new phpmailer();
			$mail->From     = $email;
			$mail->FromName = $name;
			$mail->Host     = "localhost";
			$mail->Subject = $subject;
			$mail->Sender = $email;
			$mail->Sendmail = "/usr/sbin/sendmail -t -i";
			$mail->Priority = 3;
			$mail->Encoding = "8bit";
			$mail->CharSet = "iso-8859-1";
			$mail->Helo = "localhost.chindasilpa.co.th";
			$mail->SMTPAuth = true;
			$mail->Username = "test@marisa.thaiis.com";
			$mail->Password = "test";	
			$mail->Mailer = "smtp";
			$mail->IsHTML(true);
			$mail->Body = $msg;
			$mail->AddAddress("abpcontact@thaiis.net");
			$mail->AddReplyTo($email);
			$mail->Port = 25;
			
			
			if($mail->Send()){
			 echo "<b><font size=\"3\" face=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#CC9933\">Complete</font><font size=\"2\" color=\"#CC9933\"><br>Your information has been sent</font></b>
<br><a href=\"contact.htm\"><img src=\"images/back.gif\" width=\"37\" height=\"14\" border=\"0\"></a>";

			 } else {
			 echo "Error";
			 }
	} // end if name		 ?>
                              </font></font></b></font><font color="#666666"> 
                              <b><br>
                              ABP serviced office space and meeting rooms is located 
                              in Chiang Mai, Thailand- key business destination 
                              where you need your business presence.</b> </font></strong></p>
                            <p align="left"><b>Bonking for ABP service and facility 
                              is simply with a call or a click of mouse.</b><br>
                              <b>Call Us</b> : 66-53-203456<br>
                              <b>Email Us</b> : contact@abp-businesscentre.com<br>
                              <b>Contact Us </b>: Please fill in the form below</p>
                          </div>
                        </td>
                      </tr>
                      <tr> 
                        <td height="360">
                          <table width="400" cellpadding="0" cellspacing="0" border="0">
                              <tr> 
                                <td width="175" valign="top"><b>Name<font color="#FF0000">*</font></b></td>
                                <td width="334"><font color="#CC9933"> 
                                  <? echo $name; ?>
                                  </font> </td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>Company</b></td>
                                <td width="334"> <font color="#CC9933"> 
                                  <? echo $company; ?>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>Email Address<font color="#FF0000">*</font></b></td>
                                <td width="334"> <font color="#CC9933"> 
                                  <? echo $email; ?>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>Telephone</b></td>
                                <td width="334"> <font color="#CC9933"> 
                                  <? echo $telephone; ?>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>Fax</b></td>
                                <td width="334"> <font color="#CC9933">
                                  <? echo $fax; ?>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>Mobile</b></td>
                                <td width="334"> <font color="#CC9933">
                                  <? echo $mobile; ?>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>Address</b></td>
                                <td width="334"> <font color="#CC9933">
                                  <? echo $address; ?>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>City</b></td>
                                <td width="334"> <font color="#CC9933">
                                  <? echo $city; ?>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="175" valign="top"><b>State</b></td>
                                <td width="334"> <font color="#CC9933">
                                  <? echo $state; ?>
                                  </font></td>
                              </tr>
                              <tr>
                                <td valign="top"><b>Country</b></td>
                                <td><font color="#CC9933">
                                  <? echo $country; ?>
                                  </font></td>
                              </tr>
                              <tr>
                                <td valign="top"><b>Pastal Code</b></td>
                                <td><font color="#CC9933">
                                  <? echo $postalcode; ?>
                                  </font></td>
                              </tr>
                            </table>
                          <br>
                          <table width="400" cellpadding="0" cellspacing="0" border="0">
                            <tr> 
                              <td width="133" valign="top"><b>Service Type</b></td>
                              <td colspan="2"> <font color="#CC9933"> 
                                <? echo $service; ?>
                                </font><br>
                                <font color="#CC9933"> 
                                <? echo $virtual; ?>
                                </font><br>
                                <font color="#CC9933"> 
                                <? echo $metting; ?>
                                </font></td>
                            </tr>
                            <tr> 
                              <td width="133" valign="top"><b>Size of Office</b></td>
                              <td width="128"> <font color="#CC9933"> 
                                <? echo $width; ?>
                                </font></td>
                              <td width="139"> <font color="#CC9933"> 
                                <? echo $length; ?>
                                </font></td>
                            </tr>
                            <tr> 
                              <td width="133" valign="top"><b>No. of Staff</b></td>
                              <td width="128"><b> <font color="#CC9933"> 
                                <? echo $staff; ?>
                                </font></b></td>
                              <td width="139"><b></b></td>
                            </tr>
                            <tr> 
                              <td width="133" valign="top"><b>Expected Move-in 
                                Time</b></td>
                              <td colspan="2"><b></b><b> <font color="#CC9933"> 
                                <? echo $date; ?>
                                </font>/ <font color="#CC9933"> 
                                <? echo $month; ?>
                                </font>/<font color="#CC9933"> 
                                <? echo $year; ?>
                                </font></b></td>
                            </tr>
                            <tr> 
                              <td colspan="3" valign="top">&nbsp; </td>
                            </tr>
                            <tr> 
                              <td width="133" height="20" valign="top"><b>Additional 
                                Requirements</b></td>
                              <td colspan="2" valign="top"> 
                                <p><b> <font color="#CC9933"> 
                                  <? echo $requirements; ?>
                                  </font></b></p>
                              </td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                      </tbody> 
                    </table>
                    <div align="center"><br>
                    </div>
                    <br>
                  </form>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p></p>
                  <p></p>
                  <!-- #EndEditable --></td>
              </tr>
            </table>
            <table width="516" border="0" height="34">
              <tr> 
                <td width="46">&nbsp;</td>
                <td>
<hr>
                  <b><span class="small"><img src="images/link.jpg" width="24" height="24"></span><font color="#CC6666">Site 
                  map</font> <br>
                  <a href="index.htm"><span class="small">Home</span></a><span class="small"> 
                  |<a href="about.htm">About ABP</a>|<a href="solution.htm">ABP 
                  Solution</a> </span></b><span class="small">| <a href="smartoffice.htm">Smart 
                  Office</a>| <a href="virtualoffice.htm">Virtual Office</a>| 
                  <a href="businesscenter.htm">Business Center</a><b>|<a href="option.htm">Support 
                  Service</a>|<a href="serviceoption.htm">Service Option</a>|<a href="location.htm">Location</a></b>| 
                  <a href="map.htm">Map</a><b>|<a href="floorplan.htm">Floor 
                  Plan</a></b>| <a href="virtual.htm">Slide Show</a>| <a href="virtual1.htm">Landscape</a>| 
                  <a href="virtual2.htm">Entrance</a>| <a href="virtual3.htm">Reception</a>| 
                  <a href="virtual4.htm">Meeting Room</a>| <a href="virtual5.htm">Coffee 
                  Corner</a>| <a href="virtual6.htm">Smart Office</a><b> |<a href="contact.htm">Contact 
                  Us</a></b>|</span></td>
              </tr>
            </table>
            <p align="left">&nbsp;</p>
          </td>
        </tr>
      </table>
      <table width="772" bgcolor="#009999">
        <tr> 
          <td width="192">&nbsp;</td>
          <td width="417"><img src="images/c.gif"></td>
          <td width="147">&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
